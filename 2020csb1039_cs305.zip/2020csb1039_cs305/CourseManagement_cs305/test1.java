public class test1 {
    public static void test1Test(){
        System.out.println("Hello World");
    }
}
