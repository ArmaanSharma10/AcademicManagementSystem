--Navigation is by entering the option number of the options onscreen
--To go back you have to wait till a command asks you to enter -1 to go back, keep entering random inputs in a menu until this command appears
--To go ahead you have to go past the "go back command", press random inputs until relevant menu appears
(Ex- you will have to press enter after entering student menu to reach the screen where you can give in login information)
--In test files, the file location for grade upload/curriculum upload need to be updated
--Error handling has been done in most places
--After entering wrong information you will need to go through the whole process in order to enter the right information again, press (-1) in order to not commit the wrong information
--Data entered from files is assumed to be error-free